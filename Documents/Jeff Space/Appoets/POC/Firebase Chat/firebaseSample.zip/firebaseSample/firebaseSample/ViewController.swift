//
//  ViewController.swift
//  firebaseSample
//
//  Created by Jenish.x on 20/02/18.
//  Copyright © 2018 Jenish.x. All rights reserved.
//

import UIKit
import Firebase
//MARK: Cells.
class IncommingTextCell: UITableViewCell {
    
    @IBOutlet weak var Bg: UIImageView!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var isReadstatus_img: UIImageView!
    @IBOutlet weak var message: UILabel!
    
    override func awakeFromNib() {
        Utility().changeImage("bubble_sent", bgimageview: Bg, color: UIColor.yellow)
        
    }
    
    
}

class OutgoingTextCell: UITableViewCell {
    @IBOutlet weak var Bg: UIImageView!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var isReadstatus_img: UIImageView!
    @IBOutlet weak var message: UILabel!
    
    override func awakeFromNib() {
        Utility().changeImage("bubble_received", bgimageview: Bg, color: UIColor.lightGray)
    }
}


struct Message {
    var message: String = ""
    var date_:String    = ""
    var userid: String  = ""
    var senderid:String = ""
    var read:String     = ""
    var Key_:String     = ""
    
    // Image...
    var MediaType:String = ""
    var MediaUrl:String   = ""
    
    // Voice...
    init(MessageType:String,message:String,date:String,senderid:String,userid:String,mediaUrl:String,read:String,key_value:String) {
        self.message     = message
        self.date_       = date
        self.senderid    = senderid
        self.userid      = userid
        self.MediaType   = MessageType
        self.MediaUrl    = mediaUrl
        self.read        = read
        self.Key_        = key_value
    }
    
}
class ViewController: UIViewController {
    
    @IBOutlet weak var Chat_tableview: UITableView!
    @IBOutlet weak var MessageText_view: UITextView!
    @IBOutlet weak var Message_txtview_height: NSLayoutConstraint!
    
    let storage = Storage()
    var messages: [Message] = []
    var ref: DatabaseReference!
    let StorageReferance:StorageReference! = nil
    
    let Chat_id    = "1234567890" //--- must change ---
    let USER_id    = "1234"       //--- must change ---
    let PARTNER_id = "5678"    //--- must change ---
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Chat_tableview.dataSource = self
        Chat_tableview.delegate   = self
        
        // Delegate...
        ref = Database.database().reference()
        readMessage()
    }
    //MARK: - Update value to firebase.
    func Updatefirebase(message:String,fir_key:String) -> Void {
        let userref = self.ref.child(Chat_id).child(fir_key)
        userref.updateChildValues(["read":message])
    }
    
    func readMessage(){
        ref.child(Chat_id).observe(.value, with: { (snapshot) in
            
            if snapshot.exists() {
                
                self.messages.removeAll()
                let sorted = ((snapshot.value! as AnyObject).allValues as NSArray).sortedArray(using: [NSSortDescriptor(key: "timestamp",ascending: false)])
                
                let allKeys:[String] = (snapshot.value! as AnyObject).allKeys as! [String]
                for (index,element) in sorted.enumerated() {
                    
                    let key:String       = allKeys[index]
                    
                    let message:String   = ((element as AnyObject)["text"]! as? String)!
                    let datevalue:String = "\((element as AnyObject)["timestamp"]! ?? "")"
                    let userid:String    = "\((element as AnyObject)["user"]! ?? "")"
                    let Senderid:String  = "\((element as AnyObject)["sender"]! ?? "")"
                    let Mediaurl:String  = "\((element as AnyObject)["url"]! ?? "")"
                    let Read:String      = "\((element as AnyObject)["read"]! ?? "")"
                    
                    // Type...
                    let MessageType:String  = ((element as AnyObject)["type"]! as? String)!
                    
                    let m = Message(MessageType: MessageType, message: message, date: datevalue, senderid: Senderid, userid: userid, mediaUrl: Mediaurl, read: Read, key_value: key)
                    self.messages.append(m)
                }
                
                if self.messages.count > 0
                {
                    DispatchQueue.main.async(execute: {
                        self.messages.reverse() // Revers message...
                        self.Chat_tableview.reloadData()
                        if self.messages.count < 2{return}
                        self.Chat_tableview.scrollToRow(at: IndexPath(row: self.messages.count - 1, section: 0), at: .bottom, animated: false)
                    })
                }
            }
            
        }) { (error) in
            print(error.localizedDescription)
        }
        
        
    }
    
    func WritemessagetoDatabase(message:String,messagetype:Int,MediaUrl:String) -> Void {
        var MessageType:String = ""
        MessageText_view.resignFirstResponder()  // dismiss keyboard.
        switch messagetype {
        case 0:
            MessageType = "text"
            break
        case 1:
            MessageType = "image"
            break
        case 2:
            MessageType = "video"
            break
        case 3:
            MessageType = "voice"
            break
        default:
            break
        }
        
        var messagedic:[String:Any] = [String:Any]()
        messagedic["type"]  = MessageType  // message -> type
        
        let timestamp = Date().timeIntervalSince1970
        
        messagedic["text"]       = message
        messagedic["timestamp"]  = "\(timestamp)"
        messagedic["sender"]     = PARTNER_id
        messagedic["user"]       = USER_id
        messagedic["url"]        = MediaUrl
        messagedic["read"]       = "0"
        let key = ref.childByAutoId().key
        self.ref.child(Chat_id).child(key).setValue(messagedic)
        ref.observe(.childAdded, with: { (snapshot) -> Void in
            
        })
    }
    
    //MARK: SEND BUTTON ACTION....
    @IBAction func Send_buttonAction(_ sender: UIButton) {
        
        if MessageText_view.text == "" || MessageText_view.text == "Enter message"
        {
            return
        }
        
        self.WritemessagetoDatabase(message: MessageText_view.text, messagetype: 0, MediaUrl: "") // write text message..
    }
    
    
}
extension ViewController:UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let tableCell = tableView.dequeueReusableCell(withIdentifier: "cell")
        let message:Message = messages[indexPath.row]
        if message.MediaType == "text"                          // Text message
        {
            
            if message.userid == USER_id  // self
            {
                let sendcell = tableView.dequeueReusableCell(withIdentifier: "OutgoingTextCell") as! OutgoingTextCell
                sendcell.message.text = message.message
                sendcell.date.text    = Utility.relativePast(for: Utility.convertToDate(dateString: message.date_))
                if message.read == "1"
                {
                    sendcell.isReadstatus_img.image = message.read == "1" ? UIImage(named: "read") :  UIImage(named: "unread")

                }else
                {
                    sendcell.isReadstatus_img.image = message.read == "1" ? UIImage(named: "read") :  UIImage(named: "unread")

                }
                return sendcell
            }else
            {
                if message.Key_.count > 2  // SET isREAD MESSAGE...
                {
                   
                    if message.read == "0"{
                           self.Updatefirebase(message: "1", fir_key: message.Key_)
                    }else
                    {
                        
                    }
                   
                }
                let Recivecell = tableView.dequeueReusableCell(withIdentifier: "IncommingTextCell") as! IncommingTextCell
                Recivecell.message.text = message.message
                Recivecell.date.text    = Utility.relativePast(for: Utility.convertToDate(dateString: message.date_));         if message.read == "1"
                {
                    Recivecell.isReadstatus_img.image = message.read == "1" ? UIImage(named: "read") :  UIImage(named: "unread")
                    
                }else
                {
                    Recivecell.isReadstatus_img.image = message.read == "1" ? UIImage(named: "read") :  UIImage(named: "unread")
                    
                }
                return Recivecell
                
            }
            
        }else if message.MediaType == "image"                     // image chat
        {
            if message.userid == USER_id   // self
            {
                
            }else
            {
                
            }
        }else if message.MediaType == "video"                     // video chat
        {
            if message.userid == USER_id   // self
            {
                
            }else
            {
                
            }
        }else if message.MediaType == "voice"                     // voice chat
        {
            if message.userid == USER_id   // self
            {
                
            }else
            {
                
            }
        }
        
        return tableCell!
    }
    //MARK: Calculate height...
    func heightForLabel(text:String,width:Int) -> CGFloat
    {
        let label:UILabel = UILabel(frame: CGRect(x: 0, y: 0, width: width, height: 20))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = UIFont.systemFont(ofSize: 15)
        label.text = text
        label.sizeToFit()
        return label.frame.height + 35
    }
}
// TEXTVIEW DELEGATE
extension ViewController:UITextViewDelegate
{
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.text == "Enter message"
        {
            MessageText_view.text = ""
            MessageText_view.textColor = UIColor.black
            Message_txtview_height.constant = 61
        }
    }
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        return true
    }
    func textViewShouldEndEditing(_ textView: UITextView) -> Bool {
        if textView.text == ""
        {
            MessageText_view.text = "Enter message"
            MessageText_view.textColor = UIColor.lightGray
        }else
        {
            MessageText_view.text = ""
            MessageText_view.textColor = UIColor.black
        }
        return true
    }
    
    
}
